20/7/2008:
In order to adapt UserAgent.java (for SE) to Java ME, just follows the indications within the source file.
