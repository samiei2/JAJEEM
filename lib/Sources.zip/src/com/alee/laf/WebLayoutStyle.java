/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf;

import sun.swing.DefaultLayoutStyle;

import javax.swing.*;
import javax.swing.plaf.UIResource;
import java.awt.*;

/**
 * User: mgarin Date: 08.10.12 Time: 14:15
 * <p/>
 * Almost the same as the MetalLookAndFeel LayoutStyle class as it fits WebLaF
 */

public class WebLayoutStyle extends DefaultLayoutStyle
{
    public static WebLayoutStyle INSTANCE = new WebLayoutStyle ();

    public int getPreferredGap ( JComponent component1, JComponent component2, ComponentPlacement type, int position, Container parent )
    {
        super.getPreferredGap ( component1, component2, type, position, parent );

        int offset = 0;
        switch ( type )
        {
            case INDENT:
                if ( position == SwingConstants.EAST || position == SwingConstants.WEST )
                {
                    int indent = getIndent ( component1, position );
                    if ( indent > 0 )
                    {
                        return indent;
                    }
                    return 12;
                }
            case RELATED:
                if ( component1.getUIClassID ().equals ( "ToggleButtonUI" ) && component2.getUIClassID ().equals ( "ToggleButtonUI" ) )
                {
                    ButtonModel sourceModel = ( ( JToggleButton ) component1 ).
                            getModel ();
                    ButtonModel targetModel = ( ( JToggleButton ) component2 ).
                            getModel ();
                    if ( ( sourceModel instanceof DefaultButtonModel ) &&
                            ( targetModel instanceof DefaultButtonModel ) &&
                            ( ( ( DefaultButtonModel ) sourceModel ).getGroup () == ( ( DefaultButtonModel ) targetModel ).getGroup () ) &&
                            ( ( DefaultButtonModel ) sourceModel ).getGroup () != null )
                    {
                        return 2;
                    }
                    return 5;
                }
                offset = 6;
                break;
            case UNRELATED:
                offset = 12;
                break;
        }
        if ( isLabelAndNonlabel ( component1, component2, position ) )
        {
            return getButtonGap ( component1, component2, position, offset + 6 );
        }
        return getButtonGap ( component1, component2, position, offset );
    }

    public int getContainerGap ( JComponent component, int position, Container parent )
    {
        super.getContainerGap ( component, position, parent );
        return getButtonGap ( component, position, 12 - getButtonAdjustment ( component, position ) );
    }

    protected int getButtonGap ( JComponent source, JComponent target, int position, int offset )
    {
        offset = super.getButtonGap ( source, target, position, offset );
        if ( offset > 0 )
        {
            int buttonAdjustment = getButtonAdjustment ( source, position );
            if ( buttonAdjustment == 0 )
            {
                buttonAdjustment = getButtonAdjustment ( target, flipDirection ( position ) );
            }
            offset -= buttonAdjustment;
        }
        if ( offset < 0 )
        {
            return 0;
        }
        return offset;
    }

    private int getButtonAdjustment ( JComponent source, int edge )
    {
        String classID = source.getUIClassID ();
        if ( classID.equals ( "ButtonUI" ) || classID.equals ( "ToggleButtonUI" ) )
        {
            if ( ( edge == SwingConstants.EAST || edge == SwingConstants.SOUTH ) )
            {
                if ( source.getBorder () instanceof UIResource )
                {
                    return 1;
                }
            }
        }
        else if ( edge == SwingConstants.SOUTH )
        {
            if ( ( classID.equals ( "RadioButtonUI" ) || classID.equals ( "CheckBoxUI" ) ) )
            {
                return 1;
            }
        }
        return 0;
    }
}