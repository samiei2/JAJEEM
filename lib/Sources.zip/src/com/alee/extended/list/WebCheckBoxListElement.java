/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.list;

import com.alee.laf.checkbox.WebCheckBox;

import java.awt.*;

/**
 * User: mgarin Date: 02.09.11 Time: 14:47
 */

public class WebCheckBoxListElement extends WebCheckBox
{
    public static final Insets defaultMargin = new Insets ( 4, 4, 4, 4 );

    public WebCheckBoxListElement ()
    {
        super ();
        updateMargin ();
    }

    public void applyComponentOrientation ( ComponentOrientation o )
    {
        super.applyComponentOrientation ( o );
        updateMargin ();
    }

    private void updateMargin ()
    {
        setMargin ( defaultMargin );
    }

    /**
     * Overridden for performance reasons.
     */

    // Doesn't work well on OpenJDK

    //    public void repaint ()
    //    {
    //    }
    //
    //    public void repaint ( long tm, int x, int y, int width, int height )
    //    {
    //    }
    //
    //    public void repaint ( Rectangle r )
    //    {
    //    }
    //
    //    public void validate ()
    //    {
    //    }
    //
    //    public void invalidate ()
    //    {
    //    }
    //
    //    public void revalidate ()
    //    {
    //    }
}
