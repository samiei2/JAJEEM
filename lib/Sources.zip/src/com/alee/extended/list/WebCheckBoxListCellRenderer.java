/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.list;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * User: mgarin Date: 02.09.11 Time: 14:50
 */

public class WebCheckBoxListCellRenderer extends DefaultListCellRenderer
{
    // Checkbox list elements cache
    protected Map<String, WebCheckBoxListElement> elements = new HashMap<String, WebCheckBoxListElement> ();

    public WebCheckBoxListCellRenderer ()
    {
        super ();
    }

    public Component getListCellRendererComponent ( JList list, Object value, int index, boolean isSelected, boolean cellHasFocus )
    {
        WebCheckBoxListCellData data = ( WebCheckBoxListCellData ) value;
        WebCheckBoxListElement renderer = getElement ( data );

        renderer.setSelected ( data.isSelected () );

        renderer.setEnabled ( list.isEnabled () );
        renderer.setFont ( list.getFont () );
        renderer.setComponentOrientation ( list.getComponentOrientation () );

        renderer.setText ( data.getValue () == null ? "" : data.getValue ().toString () );

        return renderer;
    }

    private WebCheckBoxListElement getElement ( WebCheckBoxListCellData data )
    {
        String key = data.getId ();
        if ( elements.containsKey ( key ) )
        {
            return elements.get ( key );
        }
        else
        {
            WebCheckBoxListElement wcble = new WebCheckBoxListElement ();
            elements.put ( key, wcble );
            return wcble;
        }
    }
}
