/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.painter;

import com.alee.utils.ImageUtils;
import com.alee.utils.LafUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * User: mgarin Date: 26.01.12 Time: 12:31
 */

public class TextureBackgroundPainter<E extends JComponent> extends DefaultPainter<E>
{
    private TexturePaint paint;

    public TextureBackgroundPainter ( ImageIcon icon )
    {
        this ( icon.getImage () );
    }

    public TextureBackgroundPainter ( Image image )
    {
        this ( ImageUtils.getBufferedImage ( image ) );
    }

    public TextureBackgroundPainter ( BufferedImage image )
    {
        super ();
        updatePainter ( image );
    }

    public void setImage ( BufferedImage image )
    {
        updatePainter ( image );
    }

    public BufferedImage getImage ()
    {
        return paint.getImage ();
    }

    private void updatePainter ( BufferedImage image )
    {
        this.paint = new TexturePaint ( image, new Rectangle ( 0, 0, image.getWidth (), image.getHeight () ) );
    }

    public void paint ( Graphics2D g2d, Rectangle bounds, E c )
    {
        // Determining actual rect to be filled (we don't need to fill invisible area)
        Rectangle vr = c.getVisibleRect ();
        Rectangle ar = vr.intersection ( bounds );

        // If there is anything to fill we do it
        if ( ar.width > 0 && ar.height > 0 )
        {
            Object old = LafUtils.setupImageQuality ( g2d );
            g2d.setPaint ( paint );
            g2d.fillRect ( ar.x, ar.y, ar.width, ar.height );
            LafUtils.restoreImageQuality ( g2d, old );
        }
    }
}