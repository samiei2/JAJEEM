/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.painter;

import com.alee.laf.StyleConstants;
import com.alee.utils.LafUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.awt.geom.RoundRectangle2D;

/**
 * User: mgarin Date: 23.08.12 Time: 15:38
 */

public class BorderPainter<E extends JComponent> extends DefaultPainter<E>
{
    protected int width = StyleConstants.borderWidth;
    protected int round = StyleConstants.round;
    protected Color color = StyleConstants.borderColor;
    protected Stroke stroke = null;

    public BorderPainter ()
    {
        super ();
        updateStroke ();
    }

    public BorderPainter ( int width )
    {
        super ();
        setWidth ( width );
    }

    public BorderPainter ( Color color )
    {
        super ();
        setColor ( color );
        updateStroke ();
    }

    public BorderPainter ( int width, Color color )
    {
        super ();
        setWidth ( width );
        setColor ( color );
    }

    public int getWidth ()
    {
        return width;
    }

    public void setWidth ( int width )
    {
        this.width = width;
        updateStroke ();
    }

    public int getRound ()
    {
        return round;
    }

    public void setRound ( int round )
    {
        this.round = round;
        updateStroke ();
    }

    public Color getColor ()
    {
        return color;
    }

    public void setColor ( Color color )
    {
        this.color = color;
    }

    public Stroke getStroke ()
    {
        return stroke;
    }

    public void setStroke ( Stroke stroke )
    {
        this.stroke = stroke;
    }

    protected void updateStroke ()
    {
        stroke = new BasicStroke ( getWidth (), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
    }

    public Dimension getPreferredSize ( E c )
    {
        return new Dimension ( Math.max ( width * 2, round * 2 ), Math.max ( width * 2, round * 2 ) );
    }

    public Insets getMargin ( E c )
    {
        Insets m = super.getMargin ( c );
        return new Insets ( m.top + width, m.left + width, m.bottom + width, m.right + width );
    }

    public void paint ( Graphics2D g2d, Rectangle bounds, E c )
    {
        Object aa = LafUtils.setupAntialias ( g2d );
        Stroke os = LafUtils.setupStroke ( g2d, stroke, stroke != null );

        g2d.setPaint ( color );
        g2d.draw ( getBorderShape ( bounds ) );

        LafUtils.restoreStroke ( g2d, os, stroke != null );
        LafUtils.restoreAntialias ( g2d, aa );
    }

    protected RectangularShape getBorderShape ( Rectangle bounds )
    {
        double shear = width == 1 ? 0 : ( double ) width / 2;
        if ( round > 0 )
        {
            return new RoundRectangle2D.Double ( bounds.x + shear, bounds.y + shear, bounds.width - shear * 2 - 1,
                    bounds.height - shear * 2 - 1, round * 2, round * 2 );
        }
        else
        {
            return new Rectangle2D.Double ( bounds.x + shear, bounds.y + shear, bounds.width - shear * 2 - 1,
                    bounds.height - shear * 2 - 1 );
        }
    }
}