/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.painter;

import javax.swing.*;
import java.awt.*;

/**
 * User: mgarin Date: 19.01.12 Time: 17:23
 */

public class ColorBackgroundPainter<E extends JComponent> extends DefaultPainter<E>
{
    protected Color color;

    public ColorBackgroundPainter ( Color color )
    {
        super ();
        this.color = color;
    }

    public Color getColor ()
    {
        return color;
    }

    public void setColor ( Color color )
    {
        this.color = color;
    }

    public boolean isOpaque ( E c )
    {
        return color != null && color.getAlpha () == 255;
    }

    public void paint ( Graphics2D g2d, Rectangle bounds, E c )
    {
        if ( color != null )
        {
            Rectangle r = c.getVisibleRect ().intersection ( bounds );
            g2d.setColor ( color );
            g2d.fillRect ( r.x, r.y, r.width, r.height );
        }
    }
}
