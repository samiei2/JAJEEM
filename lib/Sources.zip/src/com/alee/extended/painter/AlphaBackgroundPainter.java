/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.painter;

import com.alee.laf.StyleConstants;
import com.alee.utils.LafUtils;

import javax.swing.*;
import java.awt.*;

/**
 * User: mgarin Date: 22.12.11 Time: 17:20
 */

public class AlphaBackgroundPainter<E extends JComponent> extends DefaultPainter<E>
{
    private int size;
    private Color light;
    private Color dark;

    public AlphaBackgroundPainter ()
    {
        this ( StyleConstants.ALPHA_RECT_SIZE );
    }

    public AlphaBackgroundPainter ( int size )
    {
        this ( size, StyleConstants.LIGHT_ALPHA, StyleConstants.DARK_ALPHA );
    }

    public AlphaBackgroundPainter ( Color light, Color dark )
    {
        this ( StyleConstants.ALPHA_RECT_SIZE, light, dark );
    }

    public AlphaBackgroundPainter ( int size, Color light, Color dark )
    {
        super ();
        setSize ( size );
        setLight ( light );
        setDark ( dark );
    }

    public int getSize ()
    {
        return size;
    }

    public void setSize ( int size )
    {
        this.size = size;
    }

    public Color getLight ()
    {
        return light;
    }

    public void setLight ( Color light )
    {
        this.light = light;
    }

    public Color getDark ()
    {
        return dark;
    }

    public void setDark ( Color dark )
    {
        this.dark = dark;
    }

    public boolean isOpaque ( E c )
    {
        return true;
    }

    public void paint ( Graphics2D g, Rectangle bounds, E c )
    {
        LafUtils.drawAlphaBackground ( g, bounds.x, bounds.y, bounds.width, bounds.height, size, light, dark );
    }
}
