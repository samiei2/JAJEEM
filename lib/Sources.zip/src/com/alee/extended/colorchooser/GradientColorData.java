/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.colorchooser;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import java.awt.*;
import java.io.Serializable;

/**
 * User: mgarin Date: 23.11.12 Time: 16:28
 */

@XStreamAlias ("GradientColorData")
public class GradientColorData implements Serializable
{
    @XStreamAsAttribute
    private float location;

    @XStreamAsAttribute
    private Color color;

    public GradientColorData ( float location, Color color )
    {
        super ();
        this.location = location;
        this.color = color;
    }

    public Color getColor ()
    {
        return color;
    }

    public void setColor ( Color color )
    {
        this.color = color;
    }

    public float getLocation ()
    {
        return location;
    }

    public void setLocation ( float location )
    {
        this.location = location;
    }

    public boolean equals ( Object obj )
    {
        if ( obj == null || !( obj instanceof GradientColorData ) )
        {
            return false;
        }

        GradientColorData other = ( GradientColorData ) obj;
        return Float.compare ( getLocation (), other.getLocation () ) == 0 && getColor ().equals ( other.getColor () );
    }

    public GradientColorData clone ()
    {
        return new GradientColorData ( location, color );
    }
}
