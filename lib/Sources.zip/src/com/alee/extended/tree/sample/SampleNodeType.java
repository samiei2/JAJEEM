package com.alee.extended.tree.sample;

/**
 * Sample node type enum.
 *
 * @author Mikle Garin
 * @since 1.4
 */

public enum SampleNodeType
{
    root,
    folder,
    leaf
}