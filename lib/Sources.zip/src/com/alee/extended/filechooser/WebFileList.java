/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.filechooser;

import com.alee.extended.filefilter.DefaultFileFilter;
import com.alee.extended.filefilter.GroupType;
import com.alee.extended.filefilter.GroupedFileFilter;
import com.alee.laf.GlobalConstants;
import com.alee.laf.StyleConstants;
import com.alee.laf.list.ListUtils;
import com.alee.laf.list.WebList;
import com.alee.laf.scroll.WebScrollBarUI;
import com.alee.laf.scroll.WebScrollPane;
import com.alee.laf.text.WebTextField;
import com.alee.managers.hotkey.Hotkey;
import com.alee.managers.hotkey.HotkeyManager;
import com.alee.utils.FileUtils;
import com.alee.utils.ImageUtils;
import com.alee.utils.TextUtils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.List;

/**
 * User: mgarin Date: 05.07.11 Time: 13:09
 */

public class WebFileList extends WebList
{
    private static final String ID_PREFIX = "WFL";

    private boolean generateImagePreviews = true;

    private WebFileListCellRenderer cellRenderer;
    private Runnable startEdit = null;

    private int preferredColumnCount = 3;
    private int preferredRowCount = 3;

    private boolean showHiddenFiles = StyleConstants.showHiddenFiles;
    private DefaultFileFilter fileFilter = null;
    private DefaultFileFilter nonHiddenFileFilter = GlobalConstants.NON_HIDDEN_ONLY_FILTER;

    private String cachedImagesPrefix;

    private File currentFolder = null;

    public WebFileList ()
    {
        super ();

        // Unique list id for images cache
        cachedImagesPrefix = TextUtils.generateId ( ID_PREFIX ) + ImageUtils.IMAGE_CACHE_SEPARATOR;

        // Standard settings
        setLayoutOrientation ( JList.HORIZONTAL_WRAP );
        setVisibleRowCount ( 0 );

        // Files list renderer
        cellRenderer = new WebFileListCellRenderer ( WebFileList.this );
        setCellRenderer ( cellRenderer );

        // Updating fixed cells size
        cellRenderer.updateFixedCellSize ();

        // Installing editor
        ListUtils.installEditor ( this, new FileListCellEditor ()
        {
            private KeyAdapter keyAdapter = null;

            public void installEditor ( final JList list, final Runnable startEdit )
            {
                WebFileList.this.startEdit = startEdit;
                keyAdapter = new KeyAdapter ()
                {
                    public void keyReleased ( KeyEvent e )
                    {
                        if ( Hotkey.F2.isTriggered ( e ) )
                        {
                            startEdit.run ();
                        }
                    }
                };
                list.addKeyListener ( keyAdapter );
            }

            public void uninstallEditor ( JList list )
            {
                if ( keyAdapter != null )
                {
                    WebFileList.this.startEdit = null;
                    list.removeKeyListener ( keyAdapter );
                }
            }

            public JComponent createEditor ( JList list, int index, Object value )
            {
                WebTextField editor = ( WebTextField ) super.createEditor ( list, index, value );
                editor.setHorizontalAlignment (
                        cellRenderer.getFilesView ().equals ( FilesView.tiles ) ? WebTextField.LEFT : WebTextField.CENTER );
                return editor;
            }

            public Rectangle getEditorBounds ( JList list, int index, Object value, Rectangle cellBounds )
            {
                // Edit area
                Rectangle dpBounds = cellRenderer.getDescriptionPanel ().getBounds ();
                Dimension size = editor.getPreferredSize ();
                return new Rectangle ( dpBounds.x, dpBounds.y + dpBounds.height / 2 - size.height / 2, dpBounds.width, size.height );
            }

            public void editStarted ( JList list, int index )
            {
                HotkeyManager.disableHotkeys ();
                cellRenderer.setEditedCell ( index );
                super.editStarted ( list, index );
            }

            public void editFinished ( JList list, int index, Object oldValue, Object newValue )
            {
                HotkeyManager.enableHotkeys ();
                cellRenderer.setEditedCell ( -1 );
                super.editFinished ( list, index, oldValue, newValue );
            }

            public void editCancelled ( JList list, int index )
            {
                HotkeyManager.enableHotkeys ();
                cellRenderer.setEditedCell ( -1 );
                super.editCancelled ( list, index );
            }
        } );

        // Autoscroll to selection
        addListSelectionListener ( new ListSelectionListener ()
        {
            public void valueChanged ( ListSelectionEvent e )
            {
                if ( WebFileList.this.getSelectedIndex () != -1 )
                {
                    int index = WebFileList.this.getSelectionModel ().getLeadSelectionIndex ();
                    WebFileList.this.scrollRectToVisible ( WebFileList.this.getCellBounds ( index, index ) );
                }
            }
        } );
    }

    /**
     * Unique images cache prefix
     */

    public String getCachedImagesPrefix ()
    {
        return cachedImagesPrefix;
    }

    public void setCachedImagesPrefix ( String cachedImagesPrefix )
    {
        this.cachedImagesPrefix = cachedImagesPrefix;
    }

    /**
     * Desired columns/rows count
     */

    public void setPreferredColumnCount ( int preferredColumnCount )
    {
        this.preferredColumnCount = preferredColumnCount;
    }

    public int getPreferredColumnCount ()
    {
        return preferredColumnCount;
    }

    public int getPreferredRowCount ()
    {
        return preferredRowCount;
    }

    public void setPreferredRowCount ( int preferredRowCount )
    {
        this.preferredRowCount = preferredRowCount;
    }

    /**
     * Generate images preview or not
     */

    public boolean isGenerateImagePreviews ()
    {
        return generateImagePreviews;
    }

    public void setGenerateImagePreviews ( boolean generateImagePreviews )
    {
        this.generateImagePreviews = generateImagePreviews;
    }

    /**
     * View type
     */

    public FilesView getFilesView ()
    {
        return cellRenderer.getFilesView ();
    }

    public void setFilesView ( FilesView filesView )
    {
        cellRenderer.setFilesView ( filesView );
    }

    /**
     * Show hidden files
     */

    public boolean isShowHiddenFiles ()
    {
        return showHiddenFiles;
    }

    public void setShowHiddenFiles ( boolean showHiddenFiles )
    {
        this.showHiddenFiles = showHiddenFiles;
    }

    /**
     * Files filter
     */

    public DefaultFileFilter getFileFilter ()
    {
        return fileFilter;
    }

    public void setFileFilter ( DefaultFileFilter fileFilter )
    {
        setFileFilter ( fileFilter, true );
    }

    public void setFileFilter ( DefaultFileFilter fileFilter, boolean updateList )
    {
        // Setting new filters
        this.fileFilter = fileFilter;
        this.nonHiddenFileFilter =
                fileFilter != null ? new GroupedFileFilter ( GroupType.AND, fileFilter, GlobalConstants.NON_HIDDEN_ONLY_FILTER ) :
                        GlobalConstants.NON_HIDDEN_ONLY_FILTER;

        // Updating content
        if ( updateList )
        {
            setCurrentFolder ( getCurrentFolder () );
        }
    }

    /**
     * Folder which content to show
     */

    public File getCurrentFolder ()
    {
        return currentFolder;
    }

    public void setCurrentFolder ( File file )
    {
        // Saving selection to restore later
        Object[] oldSelection = WebFileList.this.getSelectedValues ();

        // Getting files and updating list model
        final File[] files;
        if ( file != null )
        {
            files = FileUtils.sortFiles ( getFileChilds ( file ) );
        }
        else
        {
            files = FileUtils.getDiskRoots ();
        }
        WebFileList.this.setModel ( new FileListModel ( files ) );
        WebFileList.this.updateUI ();

        // Restoring selection if its same folder
        if ( FileUtils.equals ( currentFolder, file ) )
        {
            WebFileList.this.clearSelection ();
            FileListModel actualModel = getActualModel ();
            if ( oldSelection != null && oldSelection.length > 0 && actualModel != null )
            {
                List<File> modelFiles = actualModel.getFiles ();
                for ( Object obj : oldSelection )
                {
                    int index = modelFiles.indexOf ( obj );
                    if ( index != -1 )
                    {
                        WebFileList.this.addSelectionInterval ( index, index );
                    }
                }
            }
        }
        else
        {
            this.currentFolder = file;
            WebFileList.this.clearSelection ();
            //            if ( WebFileList.this.getModel ().getSize () > 0 )
            //            {
            //                WebFileList.this.setSelectedIndex ( 0 );
            //            }
        }
    }

    private File[] getFileChilds ( File file )
    {
        return file.listFiles ( showHiddenFiles ? fileFilter : nonHiddenFileFilter );
    }

    /**
     * List cells editing
     */

    public void editSelectedCell ()
    {
        int index = getSelectedIndex ();
        if ( index != -1 )
        {
            editCell ( index );
        }
    }

    public void editCell ( int index )
    {
        if ( startEdit != null )
        {
            setSelectedIndex ( index );
            startEdit.run ();
        }
    }

    /**
     * Actual list model
     */

    public FileListModel getActualModel ()
    {
        ListModel model = getModel ();
        return model instanceof FileListModel ? ( FileListModel ) model : null;
    }

    /**
     * Proper list view to reflect desired columns/rows amount
     */

    private WebScrollPane scrollView = null;

    public WebScrollPane getScrollView ()
    {
        if ( scrollView == null )
        {
            scrollView = new WebScrollPane ( WebFileList.this )
            {
                public Dimension getPreferredSize ()
                {
                    Dimension ps = super.getPreferredSize ();
                    if ( WebFileList.this.getModel ().getSize () > 0 )
                    {
                        Insets bi = getInsets ();
                        Dimension oneCell = WebFileList.this.getCellBounds ( 0, 0 ).getSize ();
                        ps.width = oneCell.width * preferredColumnCount + bi.left + bi.right +
                                WebScrollBarUI.LENGTH + 1;
                        ps.height = oneCell.height * preferredRowCount + bi.top + bi.bottom + 1;
                    }
                    return ps;
                }
            };
        }
        return scrollView;
    }

    /**
     * Preferred size fixed to show desired width
     */

    public Dimension getPreferredSize ()
    {
        Dimension ps = super.getPreferredSize ();
        if ( WebFileList.this.getModel ().getSize () > 0 )
        {
            Dimension oneCell = WebFileList.this.getCellBounds ( 0, 0 ).getSize ();
            ps.width = oneCell.width * preferredColumnCount;
        }
        return ps;
    }
}
