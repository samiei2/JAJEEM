/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.panel;

import com.alee.extended.icon.OrientedIcon;
import com.alee.extended.label.WebVerticalLabel;
import com.alee.laf.StyleConstants;
import com.alee.laf.WebLookAndFeel;
import com.alee.laf.button.WebButton;
import com.alee.laf.label.WebLabel;
import com.alee.laf.panel.WebPanel;
import com.alee.utils.CollectionUtils;
import com.alee.utils.ImageUtils;
import com.alee.utils.SwingUtils;
import com.alee.utils.swing.DataProvider;
import com.alee.utils.swing.Timer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

/**
 * User: mgarin Date: 09.11.11 Time: 14:38
 * <p/>
 * This extended components allows you to quickly create and manipulate a collapsible pane.
 */

public class WebCollapsiblePane extends WebPanel implements SwingConstants
{
    private boolean animate = WebCollapsiblePaneStyle.animate;
    private ImageIcon expandIcon = WebCollapsiblePaneStyle.expandIcon;
    private ImageIcon collapseIcon = WebCollapsiblePaneStyle.collapseIcon;
    private Insets stateIconMargin = WebCollapsiblePaneStyle.stateIconMargin;
    private boolean rotateStateIcon = WebCollapsiblePaneStyle.rotateStateIcon;
    private boolean showStateIcon = WebCollapsiblePaneStyle.showStateIcon;
    private int stateIconPostion = WebCollapsiblePaneStyle.stateIconPostion;
    private int titlePanePostion = WebCollapsiblePaneStyle.titlePanePostion;
    private Insets contentMargin = WebCollapsiblePaneStyle.contentMargin;

    private List<CollapsiblePaneListener> listeners = new ArrayList<CollapsiblePaneListener> ();

    private ImageIcon cachedExpandIcon = null;
    private ImageIcon cachedDisabledExpandIcon = null;
    private ImageIcon cachedCollapseIcon = null;
    private ImageIcon cachedDisabledCollapseIcon = null;

    private DataProvider<Boolean> stateChangeEnabled = null;

    private boolean expanded = true;
    private float expandState = 1f;
    private float expandSpeed = 0.1f;
    private Timer animator = null;

    private boolean customTitle = false;
    private Component titleComponent;
    private Component content = null;

    private WebPanel headerPanel;
    private WebButton expandButton;
    private WebPanel contentPanel;

    public WebCollapsiblePane ()
    {
        this ( "" );
    }

    public WebCollapsiblePane ( String title )
    {
        this ( null, title );
    }

    public WebCollapsiblePane ( ImageIcon icon, String title )
    {
        this ( icon, title, null );
    }

    public WebCollapsiblePane ( String title, Component content )
    {
        this ( null, title, content );
    }

    public WebCollapsiblePane ( Icon icon, String title, Component content )
    {
        super ();
        // putClientProperty ( SwingUtils.HANDLES_ENABLE_STATE, true );

        this.content = content;

        setDrawFocus ( true );
        setUndecorated ( false );
        setWebColored ( false );
        setRound ( StyleConstants.smallRound );
        setLayout ( new BorderLayout ( 0, 0 ) );

        // Header

        headerPanel = new WebPanel ();
        headerPanel.setOpaque ( true );
        headerPanel.setUndecorated ( false );
        headerPanel.setShadeWidth ( 0 );
        headerPanel.setLayout ( new BorderLayout () );
        headerPanel.addMouseListener ( new MouseAdapter ()
        {
            public void mousePressed ( MouseEvent e )
            {
                if ( isAllowAction ( e ) )
                {
                    takeFocus ();
                }
            }

            public void mouseReleased ( MouseEvent e )
            {
                if ( isAllowAction ( e ) )
                {
                    invertExpandState ();
                }
            }

            private boolean isAllowAction ( MouseEvent e )
            {
                return SwingUtilities.isLeftMouseButton ( e ) && SwingUtils.size ( WebCollapsiblePane.this ).contains ( e.getPoint () );
            }
        } );
        updateTitlePosition ();

        updateDefaultTitleComponent ( title, icon );
        updateDefaultTitleBorder ();

        expandButton = new WebButton ( collapseIcon );
        expandButton.setUndecorated ( true );
        expandButton.setDrawFocus ( false );
        expandButton.setMoveIconOnPress ( false );
        expandButton.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                invertExpandState ();
                takeFocus ();
            }
        } );
        setStateIcons ();
        updateStateIconMargin ();
        updateStateIconPosition ();

        // Content

        contentPanel = new WebPanel ()
        {
            public Dimension getPreferredSize ()
            {
                Dimension ps = super.getPreferredSize ();
                if ( titlePanePostion == TOP || titlePanePostion == BOTTOM )
                {
                    if ( WebCollapsiblePane.this.content != null )
                    {
                        Insets insets = getInsets ();
                        ps.width = insets.left + WebCollapsiblePane.this.content.getPreferredSize ().width + insets.right;
                    }
                    if ( expandState < 1f )
                    {
                        ps.height = Math.round ( ps.height * expandState );
                    }
                }
                else
                {
                    if ( WebCollapsiblePane.this.content != null )
                    {
                        Insets insets = getInsets ();
                        ps.height = insets.top + WebCollapsiblePane.this.content.getPreferredSize ().height + insets.bottom;
                    }
                    if ( expandState < 1f )
                    {
                        ps.width = Math.round ( ps.width * expandState );
                    }
                }
                return ps;
            }
        };
        contentPanel.setOpaque ( false );
        contentPanel.setLayout ( new BorderLayout ( 0, 0 ) );
        contentPanel.setMargin ( contentMargin );
        add ( contentPanel, BorderLayout.CENTER );

        if ( this.content != null )
        {
            contentPanel.add ( this.content, BorderLayout.CENTER );
        }

        addPropertyChangeListener ( WebLookAndFeel.COMPONENT_ORIENTATION_PROPERTY, new PropertyChangeListener ()
        {
            public void propertyChange ( PropertyChangeEvent evt )
            {
                updateStateIcons ();
            }
        } );
    }

    private void takeFocus ()
    {
        if ( isShowing () && isEnabled () )
        {
            expandButton.requestFocusInWindow ();
        }
    }

    private void updateDefaultTitleComponent ()
    {
        updateDefaultTitleComponent ( getTitle (), getIcon () );
    }

    private void updateDefaultTitleComponent ( String title, Icon icon )
    {
        if ( !customTitle )
        {
            if ( titleComponent != null )
            {
                headerPanel.remove ( titleComponent );
            }
            titleComponent = createDefaultTitleComponent ( title, icon );
            headerPanel.add ( titleComponent, BorderLayout.CENTER );
        }
    }

    private void updateDefaultTitleBorder ()
    {
        if ( titleComponent != null && !customTitle )
        {
            // Updating title margin according to title pane position
            boolean ltr = getComponentOrientation ().isLeftToRight ();
            Insets margin = getIcon () != null || titlePanePostion != LEFT || titlePanePostion == RIGHT ? new Insets ( 2, 2, 2, 2 ) :
                    new Insets ( 2, 4, 2, 2 );
            if ( titlePanePostion == LEFT )
            {
                margin = new Insets ( margin.right, margin.top, margin.left, margin.bottom );
            }
            else if ( titlePanePostion == RIGHT )
            {
                margin = new Insets ( margin.left, margin.bottom, margin.right, margin.top );
            }
            ( ( WebLabel ) titleComponent ).setMargin ( margin );
        }
    }

    private void updateTitlePosition ()
    {
        updateTitleSides ();
        if ( titlePanePostion == TOP )
        {
            add ( headerPanel, BorderLayout.NORTH );
        }
        else if ( titlePanePostion == BOTTOM )
        {
            add ( headerPanel, BorderLayout.SOUTH );
        }
        else if ( titlePanePostion == LEFT )
        {
            add ( headerPanel, BorderLayout.LINE_START );
        }
        else if ( titlePanePostion == RIGHT )
        {
            add ( headerPanel, BorderLayout.LINE_END );
        }
        revalidate ();
    }

    private void updateTitleSides ()
    {
        headerPanel.setDrawSides ( expanded && titlePanePostion == BOTTOM, expanded && titlePanePostion == RIGHT,
                expanded && titlePanePostion == TOP, expanded && titlePanePostion == LEFT );
    }

    private void updateStateIconPosition ()
    {
        if ( showStateIcon )
        {
            if ( titlePanePostion == TOP || titlePanePostion == BOTTOM )
            {
                headerPanel.add ( expandButton, stateIconPostion == RIGHT ? BorderLayout.LINE_END : BorderLayout.LINE_START );
            }
            else if ( titlePanePostion == LEFT )
            {
                headerPanel.add ( expandButton, stateIconPostion == RIGHT ? BorderLayout.PAGE_START : BorderLayout.PAGE_END );
            }
            else if ( titlePanePostion == RIGHT )
            {
                headerPanel.add ( expandButton, stateIconPostion == RIGHT ? BorderLayout.PAGE_END : BorderLayout.PAGE_START );
            }
        }
        else
        {
            headerPanel.remove ( expandButton );
        }
        headerPanel.revalidate ();
    }

    private void updateStateIconMargin ()
    {
        expandButton.setMargin ( stateIconMargin );
    }

    private JComponent createDefaultTitleComponent ( String title, Icon icon )
    {
        // todo ltr!
        WebLabel defaultTitle;
        if ( titlePanePostion == LEFT )
        {
            defaultTitle = new WebVerticalLabel ( title, icon, WebLabel.LEADING, false );
        }
        else if ( titlePanePostion == RIGHT )
        {
            defaultTitle = new WebVerticalLabel ( title, icon, WebLabel.LEADING, true );
        }
        else
        {
            defaultTitle = new WebLabel ( title, icon, WebLabel.LEADING );
        }
        defaultTitle.setDrawShade ( true );
        return defaultTitle;
    }

    /**
     * State change enabler
     */

    public DataProvider<Boolean> getStateChangeEnabled ()
    {
        return stateChangeEnabled;
    }

    public void setStateChangeEnabled ( DataProvider<Boolean> stateChangeEnabled )
    {
        this.stateChangeEnabled = stateChangeEnabled;
    }

    public boolean isStateChangeEnabled ()
    {
        return stateChangeEnabled == null || stateChangeEnabled.provide ();
    }

    /**
     * Collapse and expand methods
     */

    public boolean isAnimating ()
    {
        return animator != null && animator.isRunning ();
    }

    public boolean invertExpandState ()
    {
        return invertExpandState ( animate );
    }

    public boolean invertExpandState ( boolean animate )
    {
        return setExpanded ( !isExpanded (), animate );
    }

    public boolean isExpanded ()
    {
        return expanded;
    }

    public boolean setExpanded ( boolean expanded )
    {
        return setExpanded ( expanded, isShowing () && animate );
    }

    public boolean setExpanded ( boolean expanded, boolean animate )
    {
        if ( isEnabled () )
        {
            if ( expanded )
            {
                return expand ( animate );
            }
            else
            {
                return collapse ( animate );
            }
        }
        return false;
    }

    public boolean collapse ()
    {
        return collapse ( animate );
    }

    public boolean collapse ( boolean animate )
    {
        if ( !expanded || !isStateChangeEnabled () )
        {
            return false;
        }

        stopAnimation ();

        expanded = false;
        setStateIcons ();
        fireCollapsing ();

        if ( animate && isShowing () )
        {
            animator = new Timer ( "WebCollapsiblePane.collapseTimer", StyleConstants.fastAnimationDelay, new ActionListener ()
            {
                public void actionPerformed ( ActionEvent e )
                {
                    if ( expandState > 0f )
                    {
                        expandState = Math.max ( 0f, expandState - expandSpeed );
                        WebCollapsiblePane.this.revalidate ();
                    }
                    else
                    {
                        expandState = 0f;
                        hideContent ();
                        animator.stop ();
                    }
                }
            } );
            animator.start ();
        }
        else
        {
            expandState = 0f;
            hideContent ();
        }
        return true;
    }

    private void hideContent ()
    {
        // Hide title border
        updateTitleSides ();

        // Hide content
        if ( content != null )
        {
            content.setVisible ( false );
        }

        // Update collapsible pane 
        revalidate ();
        repaint ();

        // Inform about event
        fireCollapsed ();
    }

    public boolean expand ()
    {
        return expand ( animate );
    }

    public boolean expand ( boolean animate )
    {
        if ( expanded || !isStateChangeEnabled () )
        {
            return false;
        }

        stopAnimation ();

        expanded = true;
        setStateIcons ();

        if ( content != null )
        {
            content.setVisible ( true );
        }

        // Show title border
        updateTitleSides ();

        fireExpanding ();

        if ( animate && isShowing () )
        {
            animator = new Timer ( "WebCollapsiblePane.expandTimer", StyleConstants.fastAnimationDelay, new ActionListener ()
            {
                public void actionPerformed ( ActionEvent e )
                {
                    if ( expandState < 1f )
                    {
                        expandState = Math.min ( 1f, expandState + expandSpeed );
                        WebCollapsiblePane.this.revalidate ();
                    }
                    else
                    {
                        expandState = 1f;
                        showContent ();
                        animator.stop ();
                    }
                }
            } );
            animator.start ();
        }
        else
        {
            expandState = 1f;
            showContent ();
        }
        return true;
    }

    private void showContent ()
    {
        WebCollapsiblePane.this.revalidate ();
        WebCollapsiblePane.this.repaint ();
        fireExpanded ();
    }

    private void stopAnimation ()
    {
        if ( animator != null && animator.isRunning () )
        {
            animator.stop ();
        }
    }

    /**
     * Title pane position
     */

    public int getTitlePanePostion ()
    {
        return titlePanePostion;
    }

    public void setTitlePanePostion ( int titlePanePostion )
    {
        this.titlePanePostion = titlePanePostion;
        updateDefaultTitleComponent ();
        updateDefaultTitleBorder ();
        updateTitlePosition ();
        updateStateIcons ();
        updateStateIconPosition ();
    }

    /**
     * Content component margin
     */

    public Insets getContentMargin ()
    {
        return contentMargin;
    }

    public void setContentMargin ( Insets contentMargin )
    {
        this.contentMargin = contentMargin;
        contentPanel.setMargin ( contentMargin );
        revalidate ();
    }

    public void setContentMargin ( int top, int left, int bottom, int right )
    {
        setContentMargin ( new Insets ( top, left, bottom, right ) );
    }

    public void setContentMargin ( int margin )
    {
        setContentMargin ( margin, margin, margin, margin );
    }

    /**
     * Should animate expand and collapse transitions
     */

    public boolean isAnimate ()
    {
        return animate;
    }

    public void setAnimate ( boolean animate )
    {
        this.animate = animate;
    }

    /**
     * Title text
     */

    public void setTitle ( String title )
    {
        if ( !customTitle )
        {
            ( ( WebLabel ) titleComponent ).setText ( title );
        }
    }

    public String getTitle ()
    {
        return customTitle ? null : ( ( WebLabel ) titleComponent ).getText ();
    }

    /**
     * Title icon
     */

    public void setIcon ( Icon icon )
    {
        if ( !customTitle )
        {
            ( ( WebLabel ) titleComponent ).setIcon ( icon );
            updateDefaultTitleBorder ();
        }
    }

    public Icon getIcon ()
    {
        return customTitle ? null : ( ( WebLabel ) titleComponent ).getIcon ();
    }

    /**
     * Collapse button icon
     */

    public ImageIcon getCollapseIcon ()
    {
        return collapseIcon;
    }

    public void setCollapseIcon ( ImageIcon collapseIcon )
    {
        this.collapseIcon = collapseIcon;
        clearCachedCollapseIcons ();
        setStateIcons ();
    }

    /**
     * Expand button icon
     */

    public ImageIcon getExpandIcon ()
    {
        return expandIcon;
    }

    public void setExpandIcon ( ImageIcon expandIcon )
    {
        this.expandIcon = expandIcon;
        clearCachedExpandIcons ();
        setStateIcons ();
    }

    /**
     * State icon margin
     */

    public Insets getStateIconMargin ()
    {
        return stateIconMargin;
    }

    public void setStateIconMargin ( Insets stateIconMargin )
    {
        this.stateIconMargin = stateIconMargin;
        updateStateIconMargin ();
    }

    /**
     * Should rotate state icon according to title position
     */

    public boolean isRotateStateIcon ()
    {
        return rotateStateIcon;
    }

    public void setRotateStateIcon ( boolean rotateStateIcon )
    {
        this.rotateStateIcon = rotateStateIcon;
        updateStateIcons ();
    }

    /**
     * Should display state icon
     */

    public boolean isShowStateIcon ()
    {
        return showStateIcon;
    }

    public void setShowStateIcon ( boolean showStateIcon )
    {
        this.showStateIcon = showStateIcon;
        updateStateIconPosition ();
    }

    /**
     * State icon position in title pane
     */

    public int getStateIconPostion ()
    {
        return stateIconPostion;
    }

    public void setStateIconPostion ( int stateIconPostion )
    {
        this.stateIconPostion = stateIconPostion;
        updateStateIconPosition ();
    }

    /**
     * Collapse and expand icons update methods
     */

    private void updateStateIcons ()
    {
        clearCachedCollapseIcons ();
        clearCachedExpandIcons ();
        setStateIcons ();
    }

    private void setStateIcons ()
    {
        if ( expanded )
        {
            expandButton.setIcon ( getCachedCollapseIcon () );
            expandButton.setDisabledIcon ( getCachedDisabledCollapseIcon () );
        }
        else
        {
            expandButton.setIcon ( getCachedExpandIcon () );
            expandButton.setDisabledIcon ( getCachedDisabledExpandIcon () );
        }
    }

    private void clearCachedCollapseIcons ()
    {
        cachedCollapseIcon = null;
        cachedDisabledCollapseIcon = null;
    }

    private ImageIcon getCachedCollapseIcon ()
    {
        if ( cachedCollapseIcon == null )
        {
            boolean ltr = getComponentOrientation ().isLeftToRight ();
            if ( !rotateStateIcon || titlePanePostion == TOP || titlePanePostion == BOTTOM )
            {
                cachedCollapseIcon = new OrientedIcon ( collapseIcon );
            }
            else if ( titlePanePostion == LEFT )
            {
                cachedCollapseIcon = ImageUtils.rotateImage90CCW ( collapseIcon );
            }
            else if ( titlePanePostion == RIGHT )
            {
                cachedCollapseIcon = ImageUtils.rotateImage90CW ( collapseIcon );
            }
        }
        return cachedCollapseIcon;
    }

    private ImageIcon getCachedDisabledCollapseIcon ()
    {
        if ( cachedDisabledCollapseIcon == null )
        {
            cachedDisabledCollapseIcon = ImageUtils.createDisabledCopy ( getCachedCollapseIcon () );
        }
        return cachedDisabledCollapseIcon;
    }

    private void clearCachedExpandIcons ()
    {
        cachedExpandIcon = null;
        cachedDisabledExpandIcon = null;
    }

    private ImageIcon getCachedExpandIcon ()
    {
        if ( cachedExpandIcon == null )
        {
            boolean ltr = getComponentOrientation ().isLeftToRight ();
            if ( !rotateStateIcon || titlePanePostion == TOP || titlePanePostion == BOTTOM )
            {
                cachedExpandIcon = expandIcon;
            }
            else if ( ltr ? titlePanePostion == LEFT : titlePanePostion == RIGHT )
            {
                cachedExpandIcon = ImageUtils.rotateImage90CCW ( expandIcon );
            }
            else if ( ltr ? titlePanePostion == RIGHT : titlePanePostion == LEFT )
            {
                cachedExpandIcon = ImageUtils.rotateImage90CW ( expandIcon );
            }
        }
        return cachedExpandIcon;
    }

    private ImageIcon getCachedDisabledExpandIcon ()
    {
        if ( cachedDisabledExpandIcon == null )
        {
            cachedDisabledExpandIcon = ImageUtils.createDisabledCopy ( getCachedExpandIcon () );
        }
        return cachedDisabledExpandIcon;
    }

    /**
     * Header panel
     */

    public WebPanel getHeaderPanel ()
    {
        return headerPanel;
    }

    /**
     * Expand button
     */

    public WebButton getExpandButton ()
    {
        return expandButton;
    }

    /**
     * Collapsible pane title component
     */

    public Component getTitleComponent ()
    {
        return titleComponent;
    }

    public void setTitleComponent ( Component titleComponent )
    {
        if ( this.titleComponent != null )
        {
            headerPanel.remove ( this.titleComponent );
        }
        if ( titleComponent != null )
        {
            headerPanel.add ( titleComponent, BorderLayout.CENTER );
        }
        this.titleComponent = titleComponent;
        this.customTitle = true;
    }

    /**
     * Collapsible pane content
     */

    public Component getContent ()
    {
        return content;
    }

    public void setContent ( Component content )
    {
        if ( this.content != null )
        {
            contentPanel.remove ( content );
        }

        this.content = content;
        content.setVisible ( expandState > 0f );

        contentPanel.add ( content, BorderLayout.CENTER );
        revalidate ();
    }

    /**
     * Collapsible pane listeners
     */

    public List<CollapsiblePaneListener> getListeners ()
    {
        return listeners;
    }

    public void setListeners ( List<CollapsiblePaneListener> listeners )
    {
        this.listeners = listeners;
    }

    public void addCollapsiblePaneListener ( CollapsiblePaneListener listener )
    {
        listeners.add ( listener );
    }

    public void removeCollapsiblePaneListener ( CollapsiblePaneListener listener )
    {
        listeners.remove ( listener );
    }

    private void fireCollapsing ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.collapsing ( this );
        }
    }

    private void fireCollapsed ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.collapsed ( this );
        }
    }

    private void fireExpanding ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.expanding ( this );
        }
    }

    private void fireExpanded ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.expanded ( this );
        }
    }

    /**
     * Visible content part
     */

    public float getExpandState ()
    {
        return expandState;
    }

    /**
     * Base preferred size (without content size)
     */

    public Dimension getBasePreferredSize ()
    {
        Dimension ps = getPreferredSize ();
        if ( content == null || expandState <= 0 )
        {
            return ps;
        }
        else
        {
            Dimension cps = content.getPreferredSize ();
            if ( titlePanePostion == TOP || titlePanePostion == BOTTOM )
            {
                return new Dimension ( ps.width, ps.height - Math.round ( cps.height * expandState ) );
            }
            else
            {
                return new Dimension ( ps.width - Math.round ( cps.width * expandState ), ps.height );
            }
        }
    }
}
