/*
* This file is part of WebLookAndFeel library.
*
* WebLookAndFeel library is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* WebLookAndFeel library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.alee.extended.panel;

import com.alee.laf.panel.WebPanel;
import com.alee.laf.panel.WebPanelStyle;
import com.alee.utils.swing.DataProvider;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * User: mgarin Date: 22.01.13 Time: 17:00
 */

public class WebAccordion extends WebPanel implements SwingConstants
{
    //    public static final ImageIcon expand = WebComboBoxUI.DOWN_ICON;
    //    public static final ImageIcon collapseLeft = ImageUtils.rotateImage90CW ( WebComboBoxUI.DOWN_ICON );
    //    public static final ImageIcon collapseRight = ImageUtils.rotateImage90CCW ( WebComboBoxUI.DOWN_ICON );
    //    public static final ImageIcon disabledExpand = ImageUtils.createDisabledCopy ( expand );
    //    public static final ImageIcon disabledCollapseLeft =  ImageUtils.createDisabledCopy ( collapseLeft ) ;
    //    public static final ImageIcon disabledCollapseRight =  ImageUtils.createDisabledCopy ( collapseLeft ) ;

    //    public static final ImageIcon expand = new ImageIcon ( ImageUtils.createDownArrowImage ( 4 ) );
    //    public static final ImageIcon collapseLeft = new ImageIcon ( ImageUtils.createLeftArrowImage ( 4 ) );
    //    public static final ImageIcon collapseRight = new ImageIcon ( ImageUtils.createRightArrowImage ( 4 ) );
    //    public static final ImageIcon disabledExpand = ImageUtils.createDisabledCopy ( expand );
    //    public static final ImageIcon disabledCollapseLeft = ImageUtils.createDisabledCopy ( collapseLeft );
    //    public static final ImageIcon disabledCollapseRight = ImageUtils.createDisabledCopy ( collapseLeft );

    // Settings
    private boolean animate = WebAccordionStyle.animate;
    private int orientation = WebAccordionStyle.orientation;
    private ImageIcon expandIcon = WebAccordionStyle.expandIcon;
    private ImageIcon collapseIcon = WebAccordionStyle.collapseIcon;
    private AccordionStyle accordionStyle = WebAccordionStyle.accordionStyle;
    private boolean fillSpace = WebAccordionStyle.fillSpace;
    private boolean multiplySelectionAllowed = WebAccordionStyle.multiplySelectionAllowed;
    private int gap = WebAccordionStyle.gap;

    // Accordion layout that positions all of the components
    private AccordionLayout accordionLayout;

    // Accordion collapsible panes
    private List<WebCollapsiblePane> panes = new ArrayList<WebCollapsiblePane> ();
    private List<CollapsiblePaneListener> listeners = new ArrayList<CollapsiblePaneListener> ();

    /**
     * Basic constructors
     */

    public WebAccordion ()
    {
        this ( WebAccordionStyle.accordionStyle );
    }

    public WebAccordion ( AccordionStyle accordionStyle )
    {
        super ();
        setDrawFocus ( true );
        setWebColored ( false );
        setLayout ( new AccordionLayout () );
        updatePanesBorderStyling ();
    }

    /**
     * Should animate expand and collapse transitions
     */

    public boolean isAnimate ()
    {
        return animate;
    }

    public void setAnimate ( boolean animate )
    {
        this.animate = animate;
        updatePanesBorderStyling ();
    }

    private void updatePanesAnimation ()
    {
        for ( WebCollapsiblePane pane : panes )
        {
            pane.setAnimate ( animate );
        }
    }

    /**
     * Accordion panes orientation
     */

    public int getOrientation ()
    {
        return orientation;
    }

    public void setOrientation ( int orientation )
    {
        this.orientation = orientation;
        updatePanesBorderStyling ();
    }

    /**
     * Accordion panes icons
     */

    public ImageIcon getExpandIcon ()
    {
        return expandIcon;
    }

    public void setExpandIcon ( ImageIcon expandIcon )
    {
        this.expandIcon = expandIcon;
        updatePaneIcons ();
    }

    public ImageIcon getCollapseIcon ()
    {
        return collapseIcon;
    }

    public void setCollapseIcon ( ImageIcon collapseIcon )
    {
        this.collapseIcon = collapseIcon;
        updatePaneIcons ();
    }

    private void updatePaneIcons ()
    {
        for ( WebCollapsiblePane pane : panes )
        {
            pane.setExpandIcon ( expandIcon );
            pane.setCollapseIcon ( collapseIcon );
        }
    }

    /**
     * Accordion style type
     */

    public AccordionStyle getAccordionStyle ()
    {
        return accordionStyle;
    }

    public void setAccordionStyle ( AccordionStyle accordionStyle )
    {
        this.accordionStyle = accordionStyle;
        updatePanesBorderStyling ();
    }

    /**
     * Fill the whole available for accordion space with expanded panes
     */

    public boolean isFillSpace ()
    {
        return fillSpace;
    }

    public void setFillSpace ( boolean fillSpace )
    {
        this.fillSpace = fillSpace;
        revalidate ();
    }

    /**
     * Allow multiply expanded panes
     */

    public boolean isMultiplySelectionAllowed ()
    {
        return multiplySelectionAllowed;
    }

    public void setMultiplySelectionAllowed ( boolean multiplySelectionAllowed )
    {
        this.multiplySelectionAllowed = multiplySelectionAllowed;
        updateExpandState ( -1 );
    }

    private void updateExpandState ( int index )
    {
        if ( !multiplySelectionAllowed )
        {
            for ( int i = 0; i < panes.size (); i++ )
            {
                WebCollapsiblePane pane = panes.get ( i );
                if ( index == -1 && pane.isExpanded () )
                {
                    index = i;
                }
                if ( index != -1 && i != index && pane.isExpanded () )
                {
                    pane.setExpanded ( false );
                }
            }
        }
    }

    /**
     * Gap between panes
     */

    public int getGap ()
    {
        return gap;
    }

    public void setGap ( int gap )
    {
        this.gap = gap;
        revalidate ();
    }

    /**
     * Panes add/remove methods
     */

    public void addPane ( String title, Component content )
    {
        addPane ( panes.size (), title, content );
    }

    public void addPane ( int index, String title, Component content )
    {
        addPane ( index, new WebCollapsiblePane ( title, content ) );
    }

    public void addPane ( Icon icon, String title, Component content )
    {
        addPane ( panes.size (), icon, title, content );
    }

    public void addPane ( int index, Icon icon, String title, Component content )
    {
        addPane ( index, new WebCollapsiblePane ( icon, title, content ) );
    }

    public void addPane ( Component title, Component content )
    {
        addPane ( panes.size (), title, content );
    }

    public void addPane ( int index, Component title, Component content )
    {
        WebCollapsiblePane pane = new WebCollapsiblePane ( "", content );
        pane.setTitleComponent ( title );
        addPane ( index, pane );
    }

    private void addPane ( int index, final WebCollapsiblePane pane )
    {
        // Animation
        pane.setAnimate ( animate );

        // Proper icons
        pane.setExpandIcon ( expandIcon );
        pane.setCollapseIcon ( collapseIcon );

        // Collapsing new pane if needed
        if ( !multiplySelectionAllowed && isAnySelected () )
        {
            pane.setExpanded ( false, false );
        }

        // State change enabler
        pane.setStateChangeEnabled ( new DataProvider<Boolean> ()
        {
            public Boolean provide ()
            {
                return !fillSpace || !pane.isExpanded () || getSelectionCount () > 1;
            }
        } );

        // Adding new listener
        CollapsiblePaneListener cpl = new CollapsiblePaneAdapter ()
        {
            public void expanding ( WebCollapsiblePane pane )
            {
                updateExpandState ( panes.indexOf ( pane ) );
            }
        };
        pane.addCollapsiblePaneListener ( cpl );
        listeners.add ( cpl );

        // Adding new pane
        add ( index, pane );
        panes.add ( index, pane );

        // Updating accordion
        updatePanesBorderStyling ();
    }

    public void removePane ( int index )
    {
        removePane ( panes.get ( index ) );
    }

    private void removePane ( WebCollapsiblePane pane )
    {
        int index = panes.indexOf ( pane );

        // State change enabler
        pane.setStateChangeEnabled ( null );

        // Removing pane listener
        pane.removeCollapsiblePaneListener ( listeners.get ( index ) );
        listeners.remove ( index );

        // Removing pane
        remove ( pane );
        panes.remove ( index );

        // Updating accordion
        updatePanesBorderStyling ();
    }

    /**
     * Updates panes styling according to accordion settings
     */

    private void updatePanesBorderStyling ()
    {
        boolean united = accordionStyle.equals ( AccordionStyle.united );
        boolean separated = accordionStyle.equals ( AccordionStyle.separated );
        boolean hor = orientation == HORIZONTAL;

        // Accordion decoration
        setUndecorated ( !united );

        // Panes decoration
        for ( int i = 0; i < panes.size (); i++ )
        {
            WebCollapsiblePane pane = panes.get ( i );
            pane.setTitlePanePostion ( hor ? LEFT : TOP );
            if ( separated )
            {
                pane.setShadeWidth ( WebPanelStyle.shadeWidth );
                pane.setDrawSides ( separated, separated, separated, separated );
            }
            else
            {
                pane.setShadeWidth ( 0 );
                pane.setDrawSides ( !hor && i > 0, hor && i > 0, false, false );
            }
        }

        // Updating accordion
        revalidate ();
        repaint ();
    }

    /**
     * Selection methods
     */

    public boolean isAnySelected ()
    {
        for ( WebCollapsiblePane pane : panes )
        {
            if ( pane.isExpanded () )
            {
                return true;
            }
        }
        return false;
    }

    public int getFirstSelectedIndex ()
    {
        for ( WebCollapsiblePane pane : panes )
        {
            if ( pane.isExpanded () )
            {
                return panes.indexOf ( pane );
            }
        }
        return -1;
    }

    public int getSelectionCount ()
    {
        int count = 0;
        for ( WebCollapsiblePane pane : panes )
        {
            if ( pane.isExpanded () )
            {
                count++;
            }
        }
        return count;
    }

    /**
     * Collapsible panes settings methods
     */

    public Icon getIconAt ( int index )
    {
        return panes.get ( index ).getIcon ();
    }

    public void setIconAt ( int index, Icon icon )
    {
        panes.get ( index ).setIcon ( icon );
    }

    public String getTitleAt ( int index )
    {
        return panes.get ( index ).getTitle ();
    }

    public void setTitleAt ( int index, String title )
    {
        panes.get ( index ).setTitle ( title );
    }

    public Component getTitleComponentAt ( int index )
    {
        return panes.get ( index ).getTitleComponent ();
    }

    public void setTitleComponentAt ( int index, Component titleComponent )
    {
        panes.get ( index ).setTitleComponent ( titleComponent );
    }

    public Component getContentAt ( int index )
    {
        return panes.get ( index ).getContent ();
    }

    public void setContentAt ( int index, Component content )
    {
        panes.get ( index ).setContent ( content );
    }

    public Insets getContentMarginAt ( int index )
    {
        return panes.get ( index ).getContentMargin ();
    }

    public void setContentMarginAt ( int index, Insets margin )
    {
        panes.get ( index ).setContentMargin ( margin );
    }

    public void setContentMarginAt ( int index, int top, int left, int bottom, int right )
    {
        setContentMarginAt ( index, new Insets ( top, left, bottom, right ) );
    }

    public void setContentMarginAt ( int index, int margin )
    {
        setContentMarginAt ( index, margin, margin, margin, margin );
    }

    /**
     * Special accordion layout
     */

    private class AccordionLayout implements LayoutManager
    {
        public void addLayoutComponent ( String name, Component comp )
        {
            //
        }

        public void removeLayoutComponent ( Component comp )
        {
            //
        }

        public void layoutContainer ( Container parent )
        {
            Insets insets = parent.getInsets ();
            Dimension size = parent.getSize ();
            int x = insets.left;
            int y = insets.top;
            int w = size.width - insets.left - insets.right;
            int h = size.height - insets.top - insets.bottom;
            boolean hor = orientation == HORIZONTAL;
            if ( fillSpace )
            {
                // Computing the part available to fill in with panes content
                float totalStates = 0;
                int totalFillLength = hor ? size.width - insets.left - insets.right : size.height - insets.top - insets.bottom + gap;
                int visuallyExpanded = 0;
                int lastFillIndex = -1;
                List<Integer> base = new ArrayList<Integer> ();
                for ( WebCollapsiblePane pane : panes )
                {
                    Dimension bps = pane.getBasePreferredSize ();
                    base.add ( hor ? bps.width : bps.height );

                    float expandState = pane.getExpandState ();

                    totalStates += expandState;
                    totalFillLength -= hor ? bps.width : bps.height + gap;

                    if ( expandState > 0f )
                    {
                        lastFillIndex = panes.indexOf ( pane );
                        visuallyExpanded++;
                    }
                }
                totalStates = visuallyExpanded == 1 ? 1f : totalStates;
                totalFillLength = Math.max ( totalFillLength, 0 );

                // Layouting panes
                float end = 0f;
                for ( int i = 0; i < panes.size (); i++ )
                {
                    float expandState = panes.get ( i ).getExpandState ();
                    int length = base.get ( i );
                    if ( expandState > 0f )
                    {
                        end += ( totalFillLength * expandState / totalStates ) % 1;
                        length += Math.round ( ( float ) Math.floor ( totalFillLength * expandState / totalStates ) ) +
                                ( i == lastFillIndex ? Math.round ( end ) : 0 );
                    }
                    panes.get ( i ).setBounds ( x, y, hor ? length : w, hor ? h : length );
                    if ( hor )
                    {
                        x += length + gap;
                    }
                    else
                    {
                        y += length + gap;
                    }
                }
            }
            else
            {
                // Simply layouting panes by preferred size
                for ( WebCollapsiblePane pane : panes )
                {
                    Dimension cps = pane.getPreferredSize ();
                    pane.setBounds ( x, y, hor ? cps.width : w, hor ? h : cps.height );
                    if ( hor )
                    {
                        x += cps.width + gap;
                    }
                    else
                    {
                        y += cps.height + gap;
                    }
                }
            }
        }

        public Dimension preferredLayoutSize ( Container parent )
        {
            return getSize ( parent, true );
        }

        public Dimension minimumLayoutSize ( Container parent )
        {
            return getSize ( parent, false );
        }

        private Dimension getSize ( Container parent, boolean preferred )
        {
            Dimension ps = new Dimension ();
            boolean hor = orientation == HORIZONTAL;
            for ( WebCollapsiblePane pane : panes )
            {
                Dimension cps = preferred || !fillSpace ? pane.getPreferredSize () : pane.getBasePreferredSize ();
                if ( hor )
                {
                    ps.width += cps.width;
                    ps.height += Math.max ( ps.height, cps.height );
                }
                else
                {
                    ps.width = Math.max ( ps.width, cps.width );
                    ps.height += cps.height;
                }
            }
            if ( panes.size () > 0 )
            {
                if ( hor )
                {
                    ps.width += gap * ( panes.size () - 1 );
                }
                else
                {
                    ps.height += gap * ( panes.size () - 1 );
                }
            }

            Insets insets = parent.getInsets ();
            ps.width += insets.left + insets.right;
            ps.height += insets.top + insets.bottom;
            return ps;
        }
    }
}
