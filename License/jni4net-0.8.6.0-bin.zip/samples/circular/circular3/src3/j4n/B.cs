namespace j4n
{
	public class B: IB
	{
	  public void m2(IA a)
	  {
	     a.m1();
	  }
  }	
}