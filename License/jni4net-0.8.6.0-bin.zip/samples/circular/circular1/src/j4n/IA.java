package j4n;
public interface IA
{
  void m1();
}